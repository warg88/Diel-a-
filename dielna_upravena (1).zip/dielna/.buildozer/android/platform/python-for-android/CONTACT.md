# Contacting the Kivy Team

If you are looking to contact the Kivy Team (who are responsible for managing
the python-for-android project), including looking for support, please see our
latest [Contact Us](https://github.com/kivy/kivy/blob/master/CONTACT.md) 
document.
