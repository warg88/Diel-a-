Contact Us
==========

If you are looking to contact the Kivy Team (who are responsible for managing the
python-for-android project), including looking for support, please see our
`latest contact details <https://github.com/kivy/python-for-android/blob/master/CONTACT.md>`_.