#!/bin/bash
buildozer android debug